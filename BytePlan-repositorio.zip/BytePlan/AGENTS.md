# Instrucciones para agentes de IA — BytePlan

## Propósito
Mantener BytePlan como una aplicación de organización de tareas escolares clara, accesible y fácil de ejecutar.

## Reglas de trabajo
1. Antes de modificar el código, leé `README.md` y los documentos relevantes de `docs/`.
2. No afirmes que existe un backend, una base de datos remota, autenticación o sincronización: la versión actual guarda datos en `localStorage`.
3. Conservá el funcionamiento sin dependencias de instalación. Si proponés agregar dependencias, explicá el motivo y actualizá las instrucciones.
4. Priorizá cambios pequeños y verificables. No reemplaces funcionalidades existentes sin explicar el impacto.
5. Validá formularios, escapá los textos de usuario antes de insertarlos en HTML y no uses `eval`.
6. No agregues telemetría, rastreadores ni envío de datos a servicios externos.
7. Mantené los controles utilizables con teclado y agregá nombres accesibles a los botones que solo muestran íconos.
8. Actualizá `docs/tasks.md` y `docs/pruebas.md` si una modificación cambia el alcance o los criterios de aceptación.

## Flujo recomendado
Idea → especificación → plan → tareas → implementación → pruebas → revisión.

## Criterio de finalización
Una tarea está terminada cuando el comportamiento está implementado, los casos principales y los errores previsibles fueron probados, y la documentación relevante está actualizada. No marques como probado algo que no ejecutaste.
