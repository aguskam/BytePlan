# BytePlan

BytePlan es una aplicación web sencilla para organizar tareas escolares, fechas de entrega y prioridades. El concepto se separa de StreamFlix: en vez de una plataforma de entretenimiento, propone una herramienta de organización personal para estudiantes.

## Funcionalidades

- Panel de inicio con pendientes, tareas de hoy y tareas completadas.
- Crear, editar, completar y eliminar tareas.
- Materias personalizables y asignación de tareas por materia.
- Fecha de entrega, prioridad y estado por tarea.
- Búsqueda, filtros y ordenamiento.
- Indicador de progreso y resumen por materia.
- Guardado local en el navegador mediante `localStorage`.
- Exportación de copia de seguridad en JSON.
- Diseño adaptable a escritorio y celular.
- Datos de demostración que se pueden reiniciar.

## Cómo ejecutar

No hace falta instalar dependencias ni configurar un servidor.

1. Descargá o descomprimí el repositorio.
2. Abrí `index.html` en un navegador actualizado.
3. Empezá a crear tareas desde el botón **Nueva tarea**.

Para un entorno local más consistente, también podés abrir la carpeta con Visual Studio Code y ejecutar `index.html` con una extensión de servidor estático, por ejemplo Live Server.

## Datos y privacidad

Los datos se guardan en el almacenamiento local del navegador en el dispositivo actual. No existe backend, cuenta de usuario ni sincronización entre dispositivos. Usá **Exportar mis datos** para descargar una copia JSON. Borrar los datos del sitio o usar otro navegador puede hacer que la información deje de estar disponible.

## Estructura

```text
BytePlan/
├── index.html          # Estructura y pantallas de la aplicación
├── styles.css          # Estilos y diseño adaptable
├── app.js              # Lógica, renderizado y persistencia local
├── docs/
│   ├── idea.md         # Problema, público y propuesta de valor
│   ├── spec.md         # Requisitos funcionales y criterios de aceptación
│   ├── plan.md         # Enfoque técnico y arquitectura
│   ├── tasks.md        # Desglose de trabajo
│   ├── decisiones.md   # Decisiones técnicas y motivos
│   ├── glosario.md     # Términos del proyecto
│   └── pruebas.md      # Pruebas manuales recomendadas
└── AGENTS.md           # Instrucciones para agentes de IA
```

## Tecnologías

HTML semántico, CSS moderno y JavaScript sin framework. Esta decisión mantiene el proyecto fácil de ejecutar, revisar y modificar en una primera entrega. La tipografía se carga desde Google Fonts; si no hay conexión, se usan tipografías de respaldo.

## Estado

Versión inicial funcional de BytePlan. Las tareas y materias funcionan en el navegador; todavía no hay API, base de datos remota, autenticación ni colaboración entre usuarios.
