# Lista de tareas del proyecto

## Etapa 1 — Base del producto
- [x] Definir el problema, el público y la propuesta de valor.
- [x] Especificar requisitos funcionales y limitaciones.
- [x] Definir estructura y modelo de datos.

## Etapa 2 — Interfaz
- [x] Crear navegación lateral y vistas de inicio, tareas y hoy.
- [x] Diseñar componentes de tarea, indicadores y progreso.
- [x] Adaptar el diseño a pantallas móviles.
- [x] Crear formularios de tarea y materia.

## Etapa 3 — Funcionalidad
- [x] Crear, editar y eliminar tareas.
- [x] Cambiar el estado de una tarea.
- [x] Administrar materias personalizadas.
- [x] Buscar, filtrar y ordenar tareas.
- [x] Mostrar contadores y progreso derivados de los datos.
- [x] Guardar cambios en el navegador.
- [x] Exportar una copia de seguridad.

## Etapa 4 — Revisión
- [ ] Ejecutar las pruebas manuales descritas en `pruebas.md` en más de un navegador.
- [ ] Revisar accesibilidad con teclado y lector de pantalla.
- [ ] Añadir pruebas automatizadas si se incorpora un entorno de pruebas.
- [ ] Evaluar con estudiantes y priorizar mejoras según comentarios.
