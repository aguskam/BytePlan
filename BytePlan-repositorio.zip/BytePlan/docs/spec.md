# Especificación funcional

## Usuarios y contexto
La primera versión es una herramienta personal sin cuenta. Cada instalación del navegador tiene sus propios datos.

## Requisitos funcionales

### RF-01 — Consultar el panel
El sistema muestra cantidad de tareas pendientes, tareas para hoy, tareas completadas, una lista breve de pendientes y el progreso general.

### RF-02 — Crear tarea
El usuario puede ingresar título obligatorio, descripción opcional, materia opcional, fecha de entrega opcional, prioridad y estado inicial.

### RF-03 — Editar tarea
El usuario puede cambiar todos los campos de una tarea existente y guardar los cambios.

### RF-04 — Completar tarea
El usuario puede cambiar el estado mediante una casilla. Una tarea completada se distingue visualmente y se excluye de las tareas pendientes.

### RF-05 — Eliminar tarea
El sistema solicita confirmación antes de eliminar una tarea.

### RF-06 — Administrar materias
El usuario puede agregar materias y ver la cantidad de pendientes de cada una. No se permiten nombres vacíos ni nombres duplicados ignorando mayúsculas/minúsculas.

### RF-07 — Buscar, filtrar y ordenar
La vista de tareas permite buscar por título, descripción o materia; filtrar por estado y materia; y ordenar por fecha, prioridad o creación.

### RF-08 — Consultar tareas de hoy
La vista “Para hoy” muestra las tareas pendientes cuya fecha coincide con la fecha local del navegador.

### RF-09 — Persistencia local
Los cambios se guardan en `localStorage` y se recuperan al abrir de nuevo la aplicación en el mismo navegador.

### RF-10 — Exportar datos
El usuario puede descargar las materias y tareas como archivo JSON.

### RF-11 — Reiniciar datos de demostración
El sistema solicita confirmación y reemplaza los datos actuales por datos de ejemplo.

## Requisitos no funcionales
- Interfaz adaptable a pantallas chicas y grandes.
- Formularios con etiquetas y campos obligatorios identificables.
- No enviar datos personales a servidores.
- No requerir compilación ni instalación de paquetes.
- Textos introducidos por el usuario deben mostrarse como texto, no interpretarse como HTML.

## Criterios de aceptación
- Se puede crear, editar, completar y eliminar una tarea.
- Los contadores y el progreso se actualizan después de cada cambio.
- Buscar o aplicar filtros modifica la lista sin borrar tareas.
- Recargar la página conserva los datos.
- Exportar descarga un JSON válido.
- La aplicación se puede utilizar en escritorio y móvil.

## Limitaciones conocidas
Los datos no se comparten entre dispositivos ni usuarios. Si el almacenamiento local del sitio se borra, los datos pueden perderse; por eso se incluye exportación manual.
