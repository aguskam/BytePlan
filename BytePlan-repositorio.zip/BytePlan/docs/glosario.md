# Glosario

- **Tarea:** actividad que el usuario quiere completar.
- **Materia:** categoría académica a la que se puede asociar una tarea.
- **Fecha de entrega:** día límite opcional de una tarea.
- **Prioridad:** nivel de importancia asignado por el usuario: baja, media o alta.
- **Estado:** indica si la tarea está pendiente o completada.
- **Dashboard / panel:** pantalla que resume la información más relevante.
- **Responsive:** diseño que adapta la distribución a distintos tamaños de pantalla.
- **`localStorage`:** mecanismo del navegador para guardar datos como texto entre sesiones.
- **Persistencia:** capacidad de conservar los datos después de cerrar o recargar la página.
- **Criterio de aceptación:** condición verificable que debe cumplir una funcionalidad.
