# Idea del producto: BytePlan

## Problema
Los estudiantes suelen repartir las entregas, las fechas y los recordatorios entre chats, cuadernos y aplicaciones distintas. Eso hace más difícil saber qué es urgente y cuánto trabajo queda pendiente.

## Público objetivo
Estudiantes de secundaria y personas que cursan materias o capacitaciones y necesitan organizar entregas individuales.

## Propuesta de valor
BytePlan concentra las tareas en una pantalla sencilla. Permite asignar cada tarea a una materia, indicar la fecha de entrega y la prioridad, y consultar el avance sin crear una cuenta.

## Objetivo de la primera versión
Entregar una web usable que permita administrar tareas escolares desde un navegador y conservar los cambios en el dispositivo.

## Fuera de alcance por ahora
- Inicio de sesión y perfiles.
- Sincronización entre dispositivos.
- Trabajo colaborativo.
- Notificaciones push o correo.
- Integración con plataformas educativas.
- Aplicación móvil nativa.

## Indicadores para evaluar la idea
- Una persona puede crear y completar una tarea sin ayuda.
- Puede identificar qué tareas vencen hoy.
- Los cambios siguen presentes al recargar la página en el mismo navegador.
- La interfaz funciona en pantallas de escritorio y móviles.
