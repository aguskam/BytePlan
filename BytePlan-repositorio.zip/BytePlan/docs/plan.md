# Plan técnico

## Arquitectura
Aplicación estática de una sola página, dividida en tres archivos principales:

- `index.html`: estructura semántica, navegación, vistas y formularios.
- `styles.css`: sistema visual, componentes y adaptación responsive.
- `app.js`: modelo de datos, eventos, renderizado y persistencia.

## Modelo de datos

Materia:
- `id`: identificador estable.
- `name`: nombre visible.
- `color`: variante visual para distinguirla.

Tarea:
- `id`: identificador estable.
- `title`: texto obligatorio.
- `description`: texto opcional.
- `subjectId`: identificador de materia o cadena vacía.
- `dueDate`: fecha `YYYY-MM-DD` o cadena vacía.
- `priority`: `low`, `medium` o `high`.
- `status`: `active` o `done`.
- `createdAt`: marca temporal numérica.

## Persistencia
El estado completo se serializa como JSON en la clave `byteplan.data.v1` de `localStorage`. La carga tiene manejo básico de errores y usa datos de demostración cuando no hay un estado válido.

## Seguridad y privacidad
Los datos permanecen en el navegador. Los valores de usuario insertados en plantillas HTML se escapan. No hay autenticación porque no existe servicio remoto.

## Riesgos y mitigaciones
- Pérdida de datos del navegador: explicar el alcance de `localStorage` y ofrecer exportación JSON.
- Fechas interpretadas en distinta zona horaria: crear fechas de presentación usando componentes locales y comparar fechas `YYYY-MM-DD`.
- Datos malformados: validar la forma básica del estado almacenado y permitir reiniciar la demo.
- Crecimiento del archivo JavaScript: mantener funciones pequeñas y extraer módulos si el proyecto escala.

## Próximas etapas posibles
1. Agregar pruebas automatizadas con Vitest y un entorno de DOM.
2. Separar el código en módulos JavaScript.
3. Añadir una API y persistencia remota solo si el alcance necesita cuentas o sincronización.
