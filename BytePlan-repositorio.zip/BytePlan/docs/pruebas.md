# Pruebas manuales

Realizar estas pruebas desde un navegador actualizado. Marcar cada caso como aprobado o pendiente después de ejecutarlo.

| ID | Caso | Pasos | Resultado esperado |
|---|---|---|---|
| P-01 | Carga inicial | Abrir `index.html` por primera vez | Se muestra el panel con datos de ejemplo |
| P-02 | Crear tarea | Nueva tarea → completar título → guardar | La tarea aparece en las listas y suben los contadores correspondientes |
| P-03 | Validar título | Abrir nueva tarea y guardar con el título vacío | El navegador impide enviar el formulario |
| P-04 | Editar tarea | Abrir edición, cambiar título y guardar | Se muestra el nuevo título sin duplicar la tarea |
| P-05 | Completar tarea | Marcar la casilla de una tarea pendiente | Cambia su estado y se actualizan los indicadores |
| P-06 | Reabrir tarea | Desmarcar una tarea completada | Vuelve a aparecer como pendiente |
| P-07 | Eliminar tarea | Pulsar eliminar y confirmar | La tarea desaparece |
| P-08 | Cancelar eliminación | Pulsar eliminar y cancelar | La tarea sigue presente |
| P-09 | Agregar materia | Agregar un nombre nuevo | La materia aparece en navegación y formularios |
| P-10 | Materia duplicada | Intentar agregar el mismo nombre con otra combinación de mayúsculas | Se muestra un error y no se duplica |
| P-11 | Buscar | Escribir parte de un título en búsqueda | Solo aparecen coincidencias |
| P-12 | Filtrar | Elegir una materia y luego un estado | La lista respeta ambos filtros |
| P-13 | Ordenar | Cambiar el orden de fecha a prioridad | La lista cambia de orden sin modificar los datos |
| P-14 | Persistencia | Crear una tarea y recargar la página | La tarea sigue presente |
| P-15 | Exportar | Pulsar “Exportar mis datos” | Se descarga un archivo JSON válido |
| P-16 | Reiniciar demo | Pulsar reiniciar y confirmar | Vuelven las tareas y materias iniciales |
| P-17 | Cancelar reinicio | Pulsar reiniciar y cancelar | Se mantienen los datos existentes |
| P-18 | Móvil | Abrir en pantalla estrecha y abrir/cerrar menú | El menú se muestra y la interfaz no se desborda horizontalmente |
| P-19 | Texto especial | Crear título con `<script>alert(1)</script>` | El texto se muestra literal y no ejecuta código |
| P-20 | Teclado | Navegar con Tab, usar Enter/Espacio y Escape en modales | Los controles se pueden utilizar sin ratón y Escape cierra los modales |

## Registro de ejecución

No se deben marcar los casos como aprobados sin ejecutarlos en un navegador. La lista es un plan de prueba, no evidencia de que cada caso haya sido validado automáticamente.
