# Decisiones técnicas

## D-01 — HTML, CSS y JavaScript sin framework
**Decisión:** usar tecnologías web nativas en la primera versión.

**Motivo:** la aplicación se puede ejecutar abriendo `index.html`, sin instalar paquetes ni configurar compilación. Esto reduce barreras para revisar el proyecto en un contexto educativo.

**Costo:** al crecer, el estado y el renderizado pueden ser más difíciles de mantener que con componentes o módulos separados.

## D-02 — `localStorage` en lugar de backend
**Decisión:** persistir datos localmente en el navegador.

**Motivo:** la primera versión es personal y no requiere cuentas ni sincronización.

**Costo:** no existe copia automática ni acceso desde otro dispositivo. La exportación JSON reduce parcialmente el riesgo de pérdida.

## D-03 — Materias editables por el usuario
**Decisión:** incluir materias iniciales de demostración y permitir agregar otras.

**Motivo:** los nombres y la cantidad de materias varían según cada estudiante.

## D-04 — No incluir notificaciones
**Decisión:** no pedir permisos de notificación en la versión inicial.

**Motivo:** el valor principal se puede demostrar sin permisos del navegador ni servicios externos.
